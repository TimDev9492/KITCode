%% Pathsettings for basic matlab project path
% Called by startups from subfolders
basicpath = pwd;% Read current path
%basicpath = '';% Explicit version
