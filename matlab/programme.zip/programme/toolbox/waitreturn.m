function waitreturn
%% CALL: waitreturn
% DESCRIPTION:
% Wait for any key to continue. Info by beep and text.
%%

% Author: W. Doerfler, KIT.

beep;
fprintf('*Programmed PAUSE. Press any key to continue!\n');
pause;
