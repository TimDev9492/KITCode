function fx = fun_f(x)
fx = sin(4*pi*x);
