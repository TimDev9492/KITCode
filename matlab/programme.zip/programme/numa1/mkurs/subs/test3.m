function b = test3(a)
b = a+1;
if b<0
   return
else
   b = 1;
end