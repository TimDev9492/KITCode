function b = test2(a)
b = a+1;
