% Skript test1
b = a+1;
