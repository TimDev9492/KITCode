%% Fileoeffner numa1
% (nichtbenoetigte Files auskommentieren)
edit openfileset.m% This
edit startup.m% Start-File
edit mk_01.m% Beispiele
edit mk_02.m%
edit mk_03.m%
edit mk_04.m%
edit mk_05.m%
edit mk_06.m%
edit mk_07.m%
% edit subs\test1.m% Test-Skripte/Funktionen
% edit subs\test2.m
% edit subs\test3.m
% edit subs\test4.m
% edit subs\test5.m
% edit subs\test6.m
% edit subs\myplot1.m% Funktionsplot
% edit subs\myplot2.m
% edit subs\fun_f.m
% edit subs\fibo.m% Rekursion
% edit subs\hilbert_example.m% Hilbert-Matrix-Beispiel
% edit subs\movietest.m% Film


