%% Fileoeffner aufgaben
% (nichtbenoetigte Files auskommentieren)
edit openfileset.m% This
edit startup.m% Start-File



